public class Constants {
    static String folder = "/home/netlab/thevoice_project/";
    static String debugFolder = folder + "debug";
    static String jobFolder = folder + "jobs";
    static String finishedJobs = folder + "finishedjobs";
    static String allJobs = folder + "allJobs";
    static String doneRecording = folder + "done";
    static String tempRecording  = folder + "tempRecording";
}
